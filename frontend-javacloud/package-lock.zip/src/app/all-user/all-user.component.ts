import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service';

@Component({
  selector: 'app-all-user',
  templateUrl: './all-user.component.html',
  styleUrls: ['./all-user.component.css']
})
export class AllUserComponent implements OnInit {
  // tslint:disable-next-line: ban-types;
  users;
  constructor(public service: UserService) { }

  ngOnInit() {
    this.service.getAllUsersRequest().subscribe(resp => {
      console.log(resp);
      this.users = resp;
    }, err => {
      console.log(err);
    }, () => {
      console.log('get all users request sent');
    });
  }

}
