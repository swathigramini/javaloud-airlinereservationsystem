import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  backendURL = 'http://localhost:8082';

  constructor(public http: HttpClient) { }
  registerRequest(data) {
    console.log('service', data);
    return this.http.post(`${this.backendURL}/template/register`, data);
  }

  loginRequest(data): any {
    return this.http.post(`${this.backendURL}/template/login`, data);
  }

  getAllUsersRequest() {
    return this.http.get(`${this.backendURL}/template/getAllUsers`);
  }
}
