import { Component, OnInit, ViewChild } from '@angular/core';
import { FlightService } from '../flight.service';
import { Router } from '@angular/router';
import { NgForm } from '@angular/forms';
import { FlightDetailsService } from '../flight-details.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  @ViewChild('searchForm', { static: true }) searchFlightData: NgForm;
  flightDetailsService: any;
  constructor(public service: FlightDetailsService, public router: Router) { }
  flightDetails;

  ngOnInit() {}

  getSearchFormData() {
    console.log(this.searchFlightData.value);
    this.flightDetailsService.searchFlightRequest(this.searchFlightData.value).subscribe(resp => {
     console.log(resp);
     this.flightDetailsService.flightDetails = resp.flightDetails;
     this.flightDetails = resp.flightDetails;
     console.log(this.flightDetails);
   }, err => {
     console.log(err);
   }, () => {
     console.log('search request sent');
     this.router.navigateByUrl('/Flight-Details');
   });
  }

}
