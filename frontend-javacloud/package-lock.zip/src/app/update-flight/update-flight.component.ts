import { Component, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { FlightDetailsService } from '../flight-details.service';

@Component({
  selector: 'app-update-flight',
  templateUrl: './update-flight.component.html',
  styleUrls: ['./update-flight.component.css']
})
export class UpdateFlightComponent implements OnInit {
  @ViewChild('updateFlightForm', { static: true}) updateFlightData: NgForm;
  router: any;

  constructor(public service: FlightDetailsService) { }

  ngOnInit() {
  }
  getUpdatedFlightData() {
    console.log(this.updateFlightData.value);
    this.service.updateFlightRequest(this.updateFlightData.value).subscribe(resp => {
      console.log(resp);
      this.router.navigateByUrl('/getFlightDetails');
    }, err => {
      console.log(err);
    }, () => {
      console.log('update flight request sent');
    });
  }


}
