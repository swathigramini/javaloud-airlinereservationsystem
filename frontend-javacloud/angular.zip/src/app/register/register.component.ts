import { Component, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { UserService } from '../user.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  @ViewChild('registerForm', { static: true }) registerData: NgForm;

  constructor(public service: UserService) { }

  ngOnInit() {
  }

  getRegisterUserDate() {
    this.service.registerRequest(this.registerData.value).subscribe(resp => {
      console.log(resp);
    }, err => {
      console.log(err);
    }, () => {
      console.log('register request sent');
    });
  }

}
