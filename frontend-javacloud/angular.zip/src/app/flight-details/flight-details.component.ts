import { Component, OnInit } from '@angular/core';
import { FlightDetailsService } from '../flight-details.service';
import { Router } from '@angular/router';



@Component({
  selector: 'app-flight-details',
  templateUrl: './flight-details.component.html',
  styleUrls: ['./flight-details.component.css']
})
export class FlightDetailsComponent implements OnInit {
  flightDetails: FlightDetailsService[];

  constructor(public service: FlightDetailsService, public router: Router) { }

ngOnInit() {
  this.getFlightDetails();
}

getFlightDetails() {
  this.service.allFlights().subscribe(resp => {
    console.log(resp.flightDetails);
    this.flightDetails = resp.flightDetails;
    console.log('flightDetails component', this.flightDetails);
  }, err => {
    console.log(err);
  }, () => {
    console.log('get request is sent');
  });
}
// getUpdateFlight(flight) {
//   console.log(flight);
//   this.service.selectedFlight = flight;
//   this.router.navigateByUrl('/update-flight');
// }

}
