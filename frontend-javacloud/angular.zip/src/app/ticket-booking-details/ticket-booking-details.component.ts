import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ticket-booking-details',
  templateUrl: './ticket-booking-details.component.html',
  styleUrls: ['./ticket-booking-details.component.css']
})
export class TicketBookingDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
